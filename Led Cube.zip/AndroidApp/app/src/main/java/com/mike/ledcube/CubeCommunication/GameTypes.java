package com.mike.ledcube.CubeCommunication;

public enum GameTypes {
    Snake
}

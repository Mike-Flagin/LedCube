package com.mike.ledcube.CubeCommunication;

public enum EffectTypes {
    Fill,
    Fire
}

package com.mike.ledcube.CubeCommunication;

import java.util.ArrayList;

public class BluetoothCommands {
    public static final byte END_BYTE = 127;

    // -- Preferences --
    public static byte[] offCommand() {
        return new byte[]{0, 0, 0, END_BYTE};
    }

    public static byte[] onCommand() {
        return new byte[]{0, 0, 1, END_BYTE};
    }

    public static byte[] getStateCommand() {
        return new byte[]{0, 0, END_BYTE};
    }

    public static byte[] getBrightnessCommand() {
        return new byte[]{0, 1, END_BYTE};
    }

    public static byte[] setBrightnessCommand(int brightness) {
        if (brightness < 0 || brightness > 255) return null;
        byte b = (byte) (brightness - 128);
        return new byte[]{0, 1, 0, b, END_BYTE};
    }


    // -- Effects --
    public static byte[] getEffectCommand(EffectTypes effect, byte... params) {
        ArrayList<Byte> command = new ArrayList<>();
        command.add((byte) 1);
        switch (effect) {
            case Fill:
                command.add((byte) 0);
                for (byte b : params)
                    command.add(b);
                break;
            case Fire:
                command.add((byte) 1);
                for (byte b : params)
                    command.add(b);
                break;
        }
        command.add(END_BYTE);
        byte[] res = new byte[command.size()];
        for (int i = 0; i < res.length; i++) {
            res[i] = command.get(i);
        }
        return res;
    }

    // -- Games --
    public static byte[] getGameInitializationCommand(GameTypes game, byte... params) {
        ArrayList<Byte> command = new ArrayList<>();
        command.add((byte) 1);
        switch (game) {
            case Snake:
                command.add((byte) 0);
                for (byte b : params)
                    command.add(b);
                break;
        }
        command.add(END_BYTE);
        byte[] res = new byte[command.size()];
        for (int i = 0; i < res.length; i++) {
            res[i] = command.get(i);
        }
        return res;
    }


}